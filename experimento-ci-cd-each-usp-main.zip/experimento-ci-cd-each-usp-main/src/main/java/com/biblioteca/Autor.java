package com.biblioteca;
public class Autor {

    public String nome;
    public String sobrenome;

    public Autor() {

    }

    public Autor(String nome, String sobrenome) {
        this.nome = nome;
        this.sobrenome = sobrenome;
    }
}